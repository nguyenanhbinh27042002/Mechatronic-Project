# qrCode_scanner_web_app
qr codes reader
