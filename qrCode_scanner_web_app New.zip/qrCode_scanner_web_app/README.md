# qrCode_scanner_web_app
qr codes reader
Coding end demo web and mapping Data in FireBase

